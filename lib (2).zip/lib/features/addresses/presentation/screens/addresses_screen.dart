import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../core/theme/app_spacing.dart';
import '../providers/address_providers.dart';
import '../widgets/address_form_dialog.dart';

const _green = Color(0xFF2E7D32);

class AddressesScreen extends ConsumerWidget {
  const AddressesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final addressesAsync = ref.watch(addressListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('My Addresses')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _green,
        foregroundColor: Colors.white,
        onPressed: () => showDialog(context: context, builder: (_) => const AddressFormDialog()),
        icon: const Icon(Icons.add),
        label: const Text('Add Address'),
      ),
      body: addressesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Could not load addresses: $e')),
        data: (addresses) {
          if (addresses.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(AppSpacing.xl),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.location_off_outlined, size: 48, color: Colors.grey.shade400),
                    const SizedBox(height: AppSpacing.md),
                    const Text('No saved addresses yet.'),
                    const SizedBox(height: AppSpacing.sm),
                    const Text(
                      'Tap "Add Address" to save one for faster checkout.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(AppSpacing.md, AppSpacing.md, AppSpacing.md, 96),
            itemCount: addresses.length,
            separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
            itemBuilder: (context, index) {
              final address = addresses[index];
              return Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            address.label == 'Home'
                                ? Icons.home_outlined
                                : address.label == 'Work'
                                    ? Icons.work_outline
                                    : Icons.location_on_outlined,
                            size: 20,
                            color: _green,
                          ),
                          const SizedBox(width: AppSpacing.sm),
                          // FIXED: was Theme.of(context).textTheme.titleMedium
                          // — that default style goes light-colored in dark
                          // mode, invisible against this card, which is
                          // deliberately fixed white in every theme (same
                          // pattern as several other screens already fixed).
                          Text(address.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: Colors.black87)),
                          if (address.isDefault) ...[
                            const SizedBox(width: AppSpacing.sm),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: _green.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'Default',
                                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                      color: _green,
                                    ),
                              ),
                            ),
                          ],
                          const Spacer(),
                          PopupMenuButton<String>(
                            onSelected: (value) {
                              switch (value) {
                                case 'edit':
                                  showDialog(
                                    context: context,
                                    builder: (_) => AddressFormDialog(existing: address),
                                  );
                                  break;
                                case 'default':
                                  ref.read(addressListProvider.notifier).setDefault(address.id);
                                  break;
                                case 'delete':
                                  ref.read(addressListProvider.notifier).remove(address.id);
                                  break;
                              }
                            },
                            itemBuilder: (context) => [
                              const PopupMenuItem(value: 'edit', child: Text('Edit')),
                              if (!address.isDefault)
                                const PopupMenuItem(value: 'default', child: Text('Set as default')),
                              const PopupMenuItem(value: 'delete', child: Text('Delete')),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.sm),
                      Text(address.formatted, style: const TextStyle(color: Colors.black87)),
                      if (address.phone.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(address.phone, style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
                      ],
                      if (address.hasCoordinates) ...[
                        const SizedBox(height: AppSpacing.sm),
                        InkWell(
                          onTap: () async {
                            final uri = Uri.parse(
                              'https://www.google.com/maps/search/?api=1&query=${address.latitude},${address.longitude}',
                            );
                            if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.map_outlined, size: 16, color: _green),
                              const SizedBox(width: 4),
                              Text('View on Map', style: TextStyle(color: _green, fontSize: 12, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

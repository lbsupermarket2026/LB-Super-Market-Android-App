import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/staff_member_entity.dart';
import '../providers/employee_providers.dart';
import '../../../../../core/extensions/string_case_extensions.dart';

const _green = Color(0xFF2E7D32);

class AddEmployeeDialog extends ConsumerStatefulWidget {
  final StaffMemberEntity? existing;
  const AddEmployeeDialog({super.key, this.existing});

  @override
  ConsumerState<AddEmployeeDialog> createState() => _AddEmployeeDialogState();
}

class _AddEmployeeDialogState extends ConsumerState<AddEmployeeDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  StaffRole _role = StaffRole.employee;

  bool get _isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _nameController.text = e.name;
      _emailController.text = e.email;
      _phoneController.text = e.phone;
      _role = e.role;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final notifier = ref.read(employeeMutationProvider.notifier);
    final success = _isEditing
        ? await notifier.updateEmployee(
            uid: widget.existing!.uid,
            name: _nameController.text.trim().toTitleCase(),
            phone: _phoneController.text.trim(),
            role: _role,
          )
        : await notifier.createEmployee(
            name: _nameController.text.trim().toTitleCase(),
            email: _emailController.text.trim(),
            phone: _phoneController.text.trim(),
            password: _passwordController.text,
            role: _role,
          );

    if (!mounted) return;
    if (success) {
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(employeeMutationProvider);

    return AlertDialog(
      title: Text(_isEditing ? 'Edit Staff Member' : 'Add Staff Member'),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (state.error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(state.error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
                ),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Full Name'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _emailController,
                enabled: !_isEditing,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email (used to sign in)',
                  helperText: _isEditing ? 'Email can\'t be changed here — it\'s tied to their login account' : null,
                ),
                validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid email' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              if (!_isEditing) ...[
                const SizedBox(height: 12),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Temporary Password (min 6 characters)'),
                  validator: (v) => (v == null || v.length < 6) ? 'At least 6 characters' : null,
                ),
              ],
              const SizedBox(height: 12),
              DropdownButtonFormField<StaffRole>(
                value: _role,
                decoration: const InputDecoration(labelText: 'Role'),
                items: const [
                  DropdownMenuItem(value: StaffRole.employee, child: Text('Employee')),
                  DropdownMenuItem(value: StaffRole.admin, child: Text('Admin')),
                ],
                onChanged: (v) => setState(() => _role = v ?? StaffRole.employee),
              ),
              if (!_isEditing) ...[
                const SizedBox(height: 8),
                Text(
                  'Share this email and temporary password with them — they can change the password later from Profile.',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: _green, foregroundColor: Colors.white),
          onPressed: state.isSubmitting ? null : _submit,
          child: state.isSubmitting
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : Text(_isEditing ? 'Save' : 'Add'),
        ),
      ],
    );
  }
}

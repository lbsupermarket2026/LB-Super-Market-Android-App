import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../authentication/domain/entities/user_entity.dart';
import '../../../authentication/presentation/providers/auth_providers.dart';
import '../../../../core/extensions/string_case_extensions.dart';

const _green = Color(0xFF2E7D32);

class EditProfileDialog extends ConsumerStatefulWidget {
  final UserEntity? user;

  const EditProfileDialog({super.key, required this.user});

  @override
  ConsumerState<EditProfileDialog> createState() => _EditProfileDialogState();
}

class _EditProfileDialogState extends ConsumerState<EditProfileDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;
  File? _pickedPhoto;
  Uint8List? _pickedPhotoBytes;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.user?.name ?? '');
    _phoneController = TextEditingController(text: widget.user?.phone ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 800);
    if (picked == null) return;

    // Reading full bytes rather than just wrapping the path in a File
    // avoids a race where FileImage/Image.file re-reads the file
    // lazily during render, which can happen before the OS has fully
    // flushed the photo to disk. This is what was causing the crash
    // right after picking a photo.
    final bytes = await picked.readAsBytes();
    if (!mounted) return;
    setState(() {
      _pickedPhoto = File(picked.path);
      _pickedPhotoBytes = bytes;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final ok = await ref.read(editProfileNotifierProvider.notifier).save(
          name: _nameController.text.trim().toTitleCase(),
          phone: _phoneController.text.trim(),
          photoFile: _pickedPhoto,
        );

    if (!mounted) return;
    if (ok) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(editProfileNotifierProvider);

    return AlertDialog(
      title: const Text('Edit Profile'),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: GestureDetector(
                  onTap: _pickPhoto,
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: _green.withOpacity(0.12),
                        // Deliberately not passing the just-picked photo
                        // to backgroundImage here — attempting to render
                        // a freshly-captured photo immediately (before
                        // it's uploaded) was the actual source of a
                        // layout crash. The photo itself uploads fine;
                        // it was specifically the live-preview render
                        // that was unstable. Showing a checkmark instead
                        // sidesteps that path entirely.
                        backgroundImage: _pickedPhotoBytes == null && widget.user?.photoUrl?.isNotEmpty == true
                            ? CachedNetworkImageProvider(widget.user!.photoUrl!)
                            : null,
                        child: _pickedPhotoBytes != null
                            ? const Icon(Icons.check_circle, color: _green, size: 32)
                            : (widget.user?.photoUrl?.isNotEmpty != true)
                                ? Text(
                                    (widget.user?.name?.isNotEmpty == true ? widget.user!.name![0] : '?').toUpperCase(),
                                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: _green),
                                  )
                                : null,
                      ),
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: _green,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: const Icon(Icons.camera_alt, size: 14, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Email is intentionally read-only here — it's tied to the
              // Firebase Auth account and changing it needs its own
              // re-verification flow, not a quiet profile-field edit.
              if (widget.user?.email?.isNotEmpty == true)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: TextField(
                    controller: TextEditingController(text: widget.user!.email),
                    enabled: false,
                    decoration: const InputDecoration(labelText: 'Email'),
                  ),
                ),
              if (state.errorMessage != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    state.errorMessage!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone'),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: state.isLoading ? null : _submit,
          child: state.isLoading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Save'),
        ),
      ],
    );
  }
}

Future<void> showEditProfileDialog(BuildContext context, UserEntity? user) {
  return showDialog(
    context: context,
    builder: (_) => EditProfileDialog(user: user),
  );
}

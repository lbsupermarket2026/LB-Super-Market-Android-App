import '../../../../core/error/result.dart';
import '../repositories/order_repository.dart';

class CreateOrderUseCase {
  final OrderRepository _repository;
  const CreateOrderUseCase(this._repository);

  Future<Result<String>> call({
    required String userId,
    required List<Map<String, dynamic>> items,
    required double totalAmount,
    required String deliveryAddress,
    String? customerPhone,
    String paymentMethod = 'cod',
    String? razorpayPaymentId,
  }) {
    return _repository.createOrder(
      userId: userId,
      items: items,
      totalAmount: totalAmount,
      deliveryAddress: deliveryAddress,
      customerPhone: customerPhone,
      paymentMethod: paymentMethod,
      razorpayPaymentId: razorpayPaymentId,
    );
  }
}

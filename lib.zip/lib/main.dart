import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'app.dart';
import 'core/config/firebase_options.dart';
import 'core/services/cache_service.dart';
import 'core/services/push_notification_service.dart';

/// Default entrypoint — points at whatever DefaultFirebaseOptions
/// resolves to (single-project setup). Once you split dev/staging/prod
/// Firebase projects, use main_dev.dart / main_staging.dart / main_prod.dart
/// instead, each passing a different FirebaseOptions.
Future<void> main() async {
  await bootstrap();
}

Future<void> bootstrap({FirebaseOptions? firebaseOptions}) async {
  WidgetsFlutterBinding.ensureInitialized();

  // A widget-level build/layout exception anywhere in the app renders
  // as a small placeholder in just that spot instead of taking down
  // the whole screen — this doesn't fix the underlying cause of any
  // specific crash, but it means one bad widget can no longer become
  // a full app crash while we track down what's actually wrong.
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return const SizedBox.shrink();
  };

  await Firebase.initializeApp(
    options: firebaseOptions ?? DefaultFirebaseOptions.currentPlatform,
  );

  // Must be registered this early (before runApp) — this is what lets
  // FCM deliver notifications while the app is fully closed, not just
  // backgrounded.
  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  // Enable offline persistence — free read caching + queued writes.
  FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: true);

  await CacheService.init();

  // Route uncaught errors to Crashlytics (skip in debug to avoid noise
  // during local development).
  FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
  PlatformDispatcher.instance.onError = (error, stack) {
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    return true;
  };

  runApp(const ProviderScope(child: FreshCartApp()));
}
